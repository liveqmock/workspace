package cn.org

class ReplaceMapper {
	def parse(){
		MarkupBuilder
	}
	
	public static void main(String[] args) {
		
	}
}
