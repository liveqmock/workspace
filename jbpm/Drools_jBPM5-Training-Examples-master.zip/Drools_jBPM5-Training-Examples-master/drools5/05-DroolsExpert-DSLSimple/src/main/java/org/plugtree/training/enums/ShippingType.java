package org.plugtree.training.enums;

public enum ShippingType {
	
	STANDARD,
	EXPRESS,
	USPS;

}
