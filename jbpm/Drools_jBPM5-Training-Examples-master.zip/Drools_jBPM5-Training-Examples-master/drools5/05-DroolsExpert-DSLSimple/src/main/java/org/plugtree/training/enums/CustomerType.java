package org.plugtree.training.enums;

public enum CustomerType {
	
	NATIONAL,
	INTERNATIONAL;

}
