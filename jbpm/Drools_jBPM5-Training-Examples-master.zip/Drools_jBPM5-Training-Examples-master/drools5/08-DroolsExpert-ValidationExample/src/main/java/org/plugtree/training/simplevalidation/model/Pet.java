/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.plugtree.training.simplevalidation.model;

/**
 *
 * @author salaboy
 */
public interface Pet {
    public void makeSomeNoise();
}
