package org.plugtree.training.enums;

public enum CreditStatus {

	ACCEPTED,
	REJECTED;

}
