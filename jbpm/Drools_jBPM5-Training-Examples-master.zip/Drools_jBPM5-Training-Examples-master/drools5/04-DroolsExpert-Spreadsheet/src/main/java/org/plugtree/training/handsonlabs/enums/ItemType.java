package org.plugtree.training.handsonlabs.enums;

public enum ItemType {
	LED_TV,
	LCD_TV,
	TUBE_TV
}
