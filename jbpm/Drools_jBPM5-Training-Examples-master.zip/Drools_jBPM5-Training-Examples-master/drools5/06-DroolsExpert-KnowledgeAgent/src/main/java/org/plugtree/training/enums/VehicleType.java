package org.plugtree.training.enums;

public enum VehicleType {

	CAR,
	MOTORCYCLE;

}
