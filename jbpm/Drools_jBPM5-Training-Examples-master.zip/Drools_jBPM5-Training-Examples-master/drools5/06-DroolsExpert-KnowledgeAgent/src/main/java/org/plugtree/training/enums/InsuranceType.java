package org.plugtree.training.enums;

public enum InsuranceType {
	
	NOT_AVAILABLE,
	NORMAL,
	FULL;

}
