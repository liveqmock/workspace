/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.wordpress.salaboy;

/**
 *
 * @author salaboy
 */
public class ThresholdBreached {
    
    private Long taskId;

    public ThresholdBreached(Long taskId) {
        this.taskId = taskId;
    }

    public Long getTaskId() {
        return taskId;
    }
    
    
    
}
