package com.wordpress.salaboy.example.model;

/**
 * Created by IntelliJ IDEA.
 * User: salaboy
 * Date: 2/14/11
 * Time: 10:19 AM
 * To change this template use File | Settings | File Templates.
 */
public interface Vehicle {
    public String getType();

}
