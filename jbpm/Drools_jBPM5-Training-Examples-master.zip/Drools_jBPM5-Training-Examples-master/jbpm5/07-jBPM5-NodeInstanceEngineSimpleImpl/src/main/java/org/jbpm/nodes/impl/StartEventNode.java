/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.jbpm.nodes.impl;

/**
 *
 * @author salaboy
 */
public class StartEventNode extends AbstractBaseNode {
    
    
}
